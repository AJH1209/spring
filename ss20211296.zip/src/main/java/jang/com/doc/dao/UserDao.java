package jang.com.doc.dao;

import jang.com.doc.model.User;

public interface UserDao {
	User getUser(String userId);
}
