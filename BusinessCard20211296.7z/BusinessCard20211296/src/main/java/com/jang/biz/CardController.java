package com.jang.biz;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jang.biz.model.Card;
import com.jang.biz.sevice.CardService;

@Controller
public class CardController {

	@Autowired
	private CardService cardService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) throws Exception {
		List<Card> list = this.cardService.getCardList();

		model.addAttribute("list", list);
//		model.addAttribute("message", "??");
		return "CardList";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String addForm(Model model) {
		model.addAttribute("card", new Card());
		return "AddForm";
	}

	@RequestMapping(value = "/addSave", method = RequestMethod.POST)
	public String add(@Valid Card card, BindingResult result, RedirectAttributes rea) throws Exception {
		if (result.hasErrors()) {
			rea.addAllAttributes(result.getModel());
			return "redirect:list";
		}
		if (this.cardService.addCard(card) == 1) {
			rea.addFlashAttribute("message", "신규 등록되었습니다.");
		} else {
			rea.addFlashAttribute("message", "신규 등록에 실패하였습니다. 확인 후 다시 시도 하여주십시오");
			return "redirect:list";
		}
		return null;
		
	}
}
