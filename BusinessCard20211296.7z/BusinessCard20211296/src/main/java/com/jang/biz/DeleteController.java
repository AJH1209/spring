package com.jang.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jang.biz.sevice.CardService;

@Controller
public class DeleteController {
	@Autowired
	private CardService cardService;

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
    public String delete(int bno, RedirectAttributes rea) throws Exception {
        if (bno <= 0) {
            rea.addFlashAttribute("message", "잘못된 요청입니다.");
            return "redirect:list";
        }

        if (this.cardService.deleteCard(bno) == 1) {
            rea.addFlashAttribute("message", "삭제되었습니다.");
        } else {
            rea.addFlashAttribute("message", "삭제에 실패하였습니다. 다시 시도해주세요.");
        }

        return "redirect:list";
    }
}
