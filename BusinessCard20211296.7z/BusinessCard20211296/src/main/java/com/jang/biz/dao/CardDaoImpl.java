package com.jang.biz.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.jang.biz.model.Card;

@Repository
public class CardDaoImpl implements CardDao {

	private JdbcTemplate jdbcTemplate;
	private NamedParameterJdbcTemplate jdbcTemplate2;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		this.jdbcTemplate2 = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<Card> getCardList() {
		String SQL = "SELECT bno, bname, phone, description FROM bcard order by bno asc";
		
		RowMapper<Card> mapper = new BeanPropertyRowMapper<Card>(Card.class);
		
		List<Card> cList = (List<Card>)this.jdbcTemplate.query(SQL, mapper);
		return cList;
	}

	@Override
	public int addCard(Card card) {
		System.out.println("dao = "+ card.getBname());
		
		int MaxNO = (int)this.jdbcTemplate.queryForObject("select max(bno)+1 from bcard", Integer.class);
		card.setBno(MaxNO);
		String SQL = "INSERT INTO bcard (bno,bname,phone,description) VALUES (:bno,:bname,:phone,:description)";
		SqlParameterSource parameterSource = new BeanPropertySqlParameterSource(card);
		return this.jdbcTemplate2.update(SQL, parameterSource);
	}

	@Override
	public int deleteCard(int bno) {
		
	    String SQL = "DELETE FROM bcard WHERE bno = :bno";
	    SqlParameterSource parameterSource = new MapSqlParameterSource("bno", bno);
	    return this.jdbcTemplate2.update(SQL, parameterSource);
	}
	
	@Override
	public int updateCard(Card card) {
	    String SQL = "UPDATE bcard SET bname = :bname, phone = :phone, description = :description WHERE bno = :bno";
	    SqlParameterSource parameterSource = new BeanPropertySqlParameterSource(card);
	    return this.jdbcTemplate2.update(SQL, parameterSource);
	}


}
