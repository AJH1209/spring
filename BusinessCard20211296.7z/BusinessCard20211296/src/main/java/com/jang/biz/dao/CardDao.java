package com.jang.biz.dao;

import java.util.List;

import com.jang.biz.model.Card;

public interface CardDao {
	List<Card> getCardList();

	int addCard(Card card);

	int updateCard(Card card);

	int deleteCard(int bno);

}
