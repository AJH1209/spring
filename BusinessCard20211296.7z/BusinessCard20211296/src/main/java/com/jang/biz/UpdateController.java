package com.jang.biz;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jang.biz.model.Card;
import com.jang.biz.sevice.CardService;

@Controller
public class UpdateController {

    @Autowired
    private CardService cardService;

    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    public String showUpdateForm(@RequestParam("bno") int bno, Model model) {
        Card card = cardService.getCardById(bno);  // 수정할 명함 정보 가져오기
        model.addAttribute("card", card); // 수정할 명함 정보
        return "CardView"; // 수정 폼 JSP 페이지
    }

    // 명함 수정 처리 (POST)
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public String updateCard(@Valid Card card, BindingResult result, RedirectAttributes rea) {
        if (result.hasErrors()) {
        	return "CardView";
        }

        if (this.cardService.updateCard(card) == 1) {
            rea.addFlashAttribute("message", "명함이 수정되었습니다.");
        } else {
            rea.addFlashAttribute("message", "수정 실패. 다시 시도해주세요.");
        }
        return "redirect:list"; // 수정 후 목록 페이지로 리다이렉트
    }
}

