package com.jang.bbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SBootBbs20211296ApplicationTests {

	@Test
	void contextLoads() {
	}

}
