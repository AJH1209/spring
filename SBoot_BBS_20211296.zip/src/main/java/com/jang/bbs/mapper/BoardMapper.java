package com.jang.bbs.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.jang.bbs.model.BoardVO;

@Mapper
public interface BoardMapper {
	List<BoardVO> getBoardList();	
}
