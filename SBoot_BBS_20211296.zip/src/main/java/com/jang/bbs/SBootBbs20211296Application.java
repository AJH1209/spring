package com.jang.bbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBootBbs20211296Application {

	public static void main(String[] args) {
		SpringApplication.run(SBootBbs20211296Application.class, args);
	}

}
