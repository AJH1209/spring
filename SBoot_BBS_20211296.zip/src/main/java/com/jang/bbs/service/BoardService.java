package com.jang.bbs.service;

import java.util.List;

import com.jang.bbs.model.BoardVO;

public interface BoardService {
	List<BoardVO> getBoardList();
}
