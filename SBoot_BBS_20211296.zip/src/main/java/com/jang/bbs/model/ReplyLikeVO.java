package com.jang.bbs.model;

public class ReplyLikeVO {
	private int rlno;
	private int rno;
	private String userId;
	private String regDate;
	public int getRlno() {
		return rlno;
	}
	public void setRlno(int rlno) {
		this.rlno = rlno;
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

}
