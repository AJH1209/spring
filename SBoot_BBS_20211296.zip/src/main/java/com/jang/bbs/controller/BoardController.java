package com.jang.bbs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jang.bbs.model.BoardVO;
import com.jang.bbs.service.BoardService;
@Controller
@RequestMapping("/board")
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/list")
	public String listPage(Model model) throws Exception
	{
		List<BoardVO> blist = boardService.getBoardList();
		model.addAttribute("boardList", blist);
		return "board/list";
	}

}
