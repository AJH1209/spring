package jang.com.doc.dao;

import java.util.List;

import jang.com.doc.model.User;

public interface UserDao {
	User getUser(String userId);
	
	List<User> getUserList();
	int delete(String userId);
	int insert(User user);
	int updateUser(User user);
	
}
