package jang.com.doc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jang.com.doc.service.UserService;

@Controller
public class DeleteController {
	@Autowired
	private UserService userService;

	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String showDeletePage() {
		return "deleteForm";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public String deleteUser(String userId, Model model) {
		int rowsAffected = userService.deleteUser(userId);

		if (rowsAffected > 0) {
			model.addAttribute("message", "사용자가 삭제되었습니다.");
		} else {
			model.addAttribute("message", "삭제할 사용자가 없습니다.");
		}

		return "login"; 
	}
}
