package jang.com.doc.service;

import java.util.List;

import javax.validation.Valid;

import jang.com.doc.model.User;

public interface UserService {
	User getUser(String userId);
	
	List<User> getUserList();
	
	int insertUser(org.apache.catalina.@Valid User user);

	int insertUser(User user);

	int updateUser(User user);

	int deleteUser(String userId);
}
