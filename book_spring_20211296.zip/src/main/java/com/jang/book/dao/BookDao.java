package com.jang.book.dao;

import com.jang.book.model.Book;

public interface BookDao {
	Book gettitle(String booktitle);
}
