package com.jang.book.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jang.book.model.Book;
@Repository
public class BookDaoImpl implements BookDao {
	
    private JdbcTemplate jdbcTemplate;
    @Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public Book gettitle(String booktitle) {
        String sql = "SELECT * FROM BOOK20211296 WHERE title = ?";
        RowMapper<Book> mapper = new BeanPropertyRowMapper<Book>(Book.class);
        return this.jdbcTemplate.queryForObject(sql, mapper, booktitle);
    }
}
