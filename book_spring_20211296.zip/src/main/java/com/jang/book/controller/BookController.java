package com.jang.book.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jang.book.model.Book;
import com.jang.book.service.BookService;

@Controller
public class BookController {

	@Autowired
	private BookService bookService;

	// GET 요청 시 도서 검색 페이지로 이동
	@RequestMapping(value = "/find", method = RequestMethod.GET)
	public String toBookView(Model model) {
		model.addAttribute("book", new Book());
		return "findBook";
	}

	// POST 요청 시 도서명으로 검색
	@RequestMapping(value = "/find", method = RequestMethod.POST)
	public String onSubmit(@Valid Book book, BindingResult result, Model model) {
		if(book.getTitle() == null || book.getTitle().trim().isEmpty()) {
			result.rejectValue("title", "error.title.notblank", "도서를 입력하세요");
			model.addAllAttributes(result.getModel());
			return "findBook";
		}
		
		if (result.hasFieldErrors("title")) {
			model.addAllAttributes(result.getModel());
			return "findBook";
		}
		try {
			// 도서 검색
			Book bookTitle = this.bookService.getTitle(book.getTitle());
			model.addAttribute("book", bookTitle);
			return "bookInfo";
			
		} catch (Exception e) {
			result.rejectValue("title", "error.title.exception", "도서가 존재하지 않습니다.");
			model.addAllAttributes(result.getModel());
			return "findBook"; // 도서가 존재하지 않으면 findBook로 돌아감
		}
		
	}

}
