package com.jang.book.service;

import com.jang.book.model.Book;

public interface BookService {
	Book getTitle(String booktitle);
}
