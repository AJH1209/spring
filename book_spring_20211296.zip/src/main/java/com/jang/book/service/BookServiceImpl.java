package com.jang.book.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.jang.book.dao.BookDao;
import com.jang.book.model.Book;

@Service("bookService")
public class BookServiceImpl implements BookService{
	
	@Autowired
	private BookDao bookDao;
	
	public Book getTitle(String booktitle) {
		return bookDao.gettitle(booktitle);
	}
}
