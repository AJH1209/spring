package com.jang.book.service;

public interface BookService {

}
