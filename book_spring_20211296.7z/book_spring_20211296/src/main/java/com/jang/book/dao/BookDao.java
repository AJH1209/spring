package com.jang.book.dao;

import org.apache.catalina.User;

public interface BookDao {
	User gettitle(String title);
}
