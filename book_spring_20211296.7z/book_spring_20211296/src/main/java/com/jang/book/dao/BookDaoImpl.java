package com.jang.book.dao;

import javax.sql.DataSource;

import org.apache.catalina.User;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

public class BookDaoImpl implements BookDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	

	@Override
	public User gettitle(String title) {
//		String sql = "select * from book20211296 where title = ?";
//		RowMapper<User> mapper = new BeanPropertyRowMapper<User>(User.class);
//		User user = (User)this.jdbcTemplate.queryFor
		return null;
	}

}
