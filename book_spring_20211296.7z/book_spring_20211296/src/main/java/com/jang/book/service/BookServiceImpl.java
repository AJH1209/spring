package com.jang.book.service;

public class BookServiceImpl {

}
