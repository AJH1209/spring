package com.jang.biz.dao;

import java.util.List;

import com.jang.biz.model.Card;

public interface CardDao {
	List<Card> getCardList();
}
