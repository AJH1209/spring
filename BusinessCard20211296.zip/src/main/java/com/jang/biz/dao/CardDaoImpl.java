package com.jang.biz.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.jang.biz.model.Card;

@Repository
public class CardDaoImpl implements CardDao {
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<Card> getCardList() {
		String SQL = "SELECT bno, bname, phone, description FROM bcard order by bno asc";
		
		RowMapper<Card> mapper = new BeanPropertyRowMapper<Card>(Card.class);
		
		List<Card> cList = (List<Card>)this.jdbcTemplate.query(SQL, mapper);
		return cList;
	}

}
