package com.jang.biz;

public class UpdateController {

}
