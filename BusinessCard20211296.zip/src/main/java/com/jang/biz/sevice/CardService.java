package com.jang.biz.sevice;

import java.util.List;

import com.jang.biz.model.Card;

public interface CardService {
	List<Card> getCardList();
	
	int addCard(Card card);

	int deleteCard(int bno);
	
}
