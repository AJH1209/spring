package com.jang.biz.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jang.biz.dao.CardDao;
import com.jang.biz.model.Card;

@Service
public class CardServiceImpl implements CardService {
	@Autowired
	private CardDao cardDao;

	@Override
	public List<Card> getCardList() {
		return this.cardDao.getCardList();
	}

	@Override
	public int addCard(Card card) {
		return this.cardDao.addCard(card);
	}

	public int deleteCard(int bno) {
		return cardDao.deleteCard(bno);
	}

}
