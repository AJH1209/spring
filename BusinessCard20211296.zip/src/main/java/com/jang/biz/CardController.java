package com.jang.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jang.biz.model.Card;
import com.jang.biz.sevice.CardService;

@Controller(value = "cardConroller")
public class CardController {

	@Autowired
	private CardService cardService;

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(Model model) throws Exception {
		List<Card> list = this.cardService.getCardList();

		model.addAttribute("list", list);
//		model.addAttribute("message", "??");
		return "CardList";
	}
}
